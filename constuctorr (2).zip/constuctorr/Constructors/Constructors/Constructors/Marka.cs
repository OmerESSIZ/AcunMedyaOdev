﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace constructor
{
    public class Marka
    {
        public string markaAdi;

        public Marka(string markaAdi)
        {
            this.markaAdi = markaAdi;
        }
    }
}
