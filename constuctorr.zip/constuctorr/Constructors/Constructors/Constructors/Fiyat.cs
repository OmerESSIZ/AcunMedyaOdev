﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace constructor.Constructors
{
    public class Fiyat
    {
        public int fiyat;

        public Fiyat(int fiyat)
        {
            this.fiyat = fiyat;
        }
    }
}
