﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace constructor.Constructors
{
    public class Model
    {
        public string modelAdi;

        public Model(string modelAdi)
        {
            this.modelAdi = modelAdi;
        }
    }
}
