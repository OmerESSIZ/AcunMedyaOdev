﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace constructor
{
    public class Kapi
    {


        public int sayi;



        public Kapi(int sayi)
        {
            this.sayi = sayi;
        }
    }
}
